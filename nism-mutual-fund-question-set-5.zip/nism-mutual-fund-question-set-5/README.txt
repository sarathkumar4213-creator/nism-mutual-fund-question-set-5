NISM VD - Mutual Fund - Question Set 5
70-question interactive practice test.
Upload index.html to GitHub Pages as the site root.